//
//  UILabel+ContentSize.h
//  iOS-Foreground-Push-Notification
//
//  Created by wuxingchen on 16/8/3.
//  Copyright © 2016年 57380422@qq.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (ContentSize)
-(CGSize)caculatedSize;
@end
