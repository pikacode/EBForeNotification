//
//  UIImage+ColorAtPoint.h
//  EBForeNotification
//
//  Created by wuxingchen on 16/7/22.
//  Copyright © 2016年 57380422@qq.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (ColorAtPoint)
+(UIColor *)colorAtPoint:(CGPoint)point;
@end
